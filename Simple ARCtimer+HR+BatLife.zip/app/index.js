///////////// finally getting somewhere

import clock from "clock";
import document from "document";
import * as utils from '../common/utils';
import * as ConfigFile from '../common/configFile';
import * as messaging from "messaging";
import { HeartRateSensor } from "heart-rate";
import { locale } from "user-settings";
import { preferences } from "user-settings";
import { battery } from "power";
//////////////////////////////////////////arc
const NUM_OF_DEGREES = 360;
const NUM_OF_HOURS = 12;
const NUM_OF_MINUTES = 60;
const NUM_OF_SECONDS = 60;
//////////////////////////////////////////////////

const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];

const DEFAULT_COLOR = '#00BFFF';
const CLOCK_COLOR_KEY = 'ARCcolor';

//fetch UI elements
const arcSeconds = document.getElementById("arcSeconds");
const dElem = document.getElementById("dateText");
const hmElem = document.getElementById("hoursMinutesText");
const sElem = document.getElementById("secondsText");
const hrElem = document.getElementById("heartRateText");
const bElem = document.getElementById("batteryText");
// colors
let ARCcolor, DATEcolor, HMcolor, clockTime;
init();
clock.granularity = "seconds";

// Update current time every second
clock.ontick = (evt) => {
  clockTime = evt.date;
  render(clockTime, ARCcolor, DATEcolor, HMcolor,);
  let today = evt.date;
  dElem.text = utils.getWeekDay(today.getDay(),locale)+ " "+ today.getDate() + "." + (today.getMonth()+1) + "." + today.getFullYear();
  dElem.style.fill = ARCcolor
  
  let hours = today.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = utils.monoDigits(hours % 12 || 12, false);} 
  else {
    // 24h format
    hours = utils.zeroPad(hours);
  }
  let mins = utils.monoDigits(today.getMinutes());
  let secs = utils.monoDigits(today.getSeconds());
  hmElem.text = hours + ':' + mins;
  hmElem.style.fill = ARCcolor
  sElem.text = secs;  
  sElem.style.fill = ARCcolor
  
  if(hrs.heartRate == null){  hrElem.text = "--bpm";}
  else{ hrElem.text = hrs.heartRate + "bpm";}
  
  bElem.text =  battery.chargeLevel + "%";
  if(battery.chargeLevel >= 75){   bElem.style.fill = "lime";} 
  else if(battery.chargeLevel >= 35) {bElem.style.fill = "yellow"; }
  else{    bElem.style.fill = "red";  }
}

//HeartRateSensor
const hrs = new HeartRateSensor();
hrs.start();


// Update color when a settings message is received
messaging.peerSocket.onmessage = function(evt) {
  if (evt.data.key == CLOCK_COLOR_KEY) {
    ARCcolor = evt.data.value;
    render(clockTime, ARCcolor);
    ConfigFile.setItem(CLOCK_COLOR_KEY, ARCcolor)
    ConfigFile.save();
  }
}

function init() {  ARCcolor = CLOCK_COLOR_KEY; if(ConfigFile.load()) {  let color = ConfigFile.getItem(CLOCK_COLOR_KEY)
   ARCcolor  = color ? color : ARCcolor }
}

// you need this in order for the SecondsTick to work & the opacity starts 60% less brighter than where its supposed to be at./// Arc
function render(time, color) {
  let hours = time.getHours() % 12;
  let minutes = time.getMinutes();
  let seconds = time.getSeconds();
  let secondsOpacity = -0.6 + (seconds/100);
  arcSeconds.sweepAngle = NUM_OF_DEGREES / NUM_OF_SECONDS * seconds;
  arcSeconds.style.fill = ARCcolor
}
